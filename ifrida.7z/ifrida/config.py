import os
import datetime
import logging
cwd = os.getcwd()

ifrida_session_dir = "hook_test"
ifrida_session_dir_path = os.path.join(cwd,ifrida_session_dir)


ifrida_scripts_dir = os.path.join(cwd,"scripts")
ifrida_logger_level = logging.INFO




def get_logger(log_path,with_timestamp=True ,promot=""):
    logger_name = datetime.datetime.now().strftime('%Y-%m-%d-%H-%M-%S')
    logger = logging.getLogger(logger_name)
    logger.setLevel(ifrida_logger_level)
    sh = logging.StreamHandler()
    
    
    if with_timestamp:
        log_path = log_path + "-" + logger_name + ".log"
    else:
        log_path = log_path + ".log"
    log_path_dir , logger_name = os.path.split(log_path)
    if not os.path.exists(log_path_dir):
        os.makedirs(log_path_dir)

    fh = logging.FileHandler(filename=log_path,mode='a')

    ifrida_logger_fmt = f"%(asctime)s {promot}: %(message)s"

    fmt = logging.Formatter(fmt=ifrida_logger_fmt,datefmt="%Y-%m-%d-%H:%M:%S")
    sh.setFormatter(fmt)
    fh.setFormatter(fmt)
    logger.addHandler(sh)
    logger.addHandler(fh)
    return logger
