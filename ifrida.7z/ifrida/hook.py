
import config
import os
class HookSession:
    def __init__(self,name,frida_session,device):
        self.name = name
        self.session = frida_session
        self.device = device 
        clz_name = self.__class__.__name__
        logger_path = os.path.join(config.ifrida_session_dir_path,self.device.serial,self.name)
        self.logger = config.get_logger(logger_path,f"{clz_name}@{self.device.serial}")
    def load_script(self,load_script_path):
        pass
