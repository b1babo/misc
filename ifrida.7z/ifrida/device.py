

from shell import Shell
import platform
import config
import frida
import os
from hook import HookSession


class Device:

    def __init__(self,serial):
        self.serial = serial
        self.frida_device = None
        self.hook_sessions = {}
        logger_path = os.path.join(config.ifrida_session_dir_path,self.__class__.__name__)
        self.logger = config.get_logger(logger_path,self.serial)

    def attach_process(self,name,script=None):
        if name in self.hook_sessions:
            hook_process =  self.hook_sessions[name]
        if self.frida_device == None:
            self.get_frida_device()
        hook_session = self.frida_device.attach(name)

        hook_process = HookSession(name,hook_session,self)
        self.hook_sessions[name] = hook_process
        hook_process.load_script(script) 

    def enumerate_processes(self):
        for process in self.frida_device.enumerate_processes():
            name,pid = process.name,process.pid
            self.logger.info(f"{name} {pid}")
        

    def get_frida_device(self):
        pass

class LocalDevice(Device):
    def __init__(self):
        super().__init__("local")
    def get_frida_device(self):
        if self.frida_device != None:
            return self.frida_device
        self.frida_device = frida.get_local_device()
        return self.frida_device


class RemoteDevice(Device):

    def __init__(self,serial,adb,frida_server_port=6666):
        self.adb = adb
        self.serial = serial
        self.frida_dir = "/data/adb/tmp/"
        self.frida_ver = "frida-server-15.1.8"
        if ":" in name:
            self.remote_ip,self.remote_port = self.serial.split(":")
            self.is_usb = False

        else:
            self.is_usb = True

        self.frida_server_port=frida_server_port
        self.frida_server_ip = "0.0.0.0"

        self.run_frida_server()
    def get_frida_device(self):
        if self.frida_device != None:
            return self.frida_device
        if self.is_usb:
            self.frida_device = frida.get_usb_device()
        else:
            self.frida_device = frida.get_device_manager().add_remote_device(f"{self.remote_ip}:{self.frida_server_port}")

    def push(self, src, dst):
        return self.adb.push(self.serial,src,dst)

    def reverse(self, port):
        return self.adb.reverse(self.serial,port)

    def clear_reverse(self, remote_port):
        return self.adb.clear_reverse(self,serial, remote_port)

    def forward(self, adb_port, remote_port):
        return self.adb.forward(self.serial, adb_port, remote_port)

    def clear_forward(self, adb_port):
        return self.adb.clear_forward(self.serial, adb_port)
    def unsafe_shell(self,command, quiet=False):
        return self.adb.unsafe_shell(self.serial,command,quiet = False)
    def is_running_frida_server(self):
        if self.unsafe_shell("ps -A | grep frida-server").out == "":
            return False
        else:
            return True 
    
    def install_frida_server(self):
        if not self.is_usb:
            self.unsafe_shell(f"{os.path.join(self.frida_dir,self.frida_ver)} -l {self.frida_server_ip}:{self.frida_server_port} &")
    def run_frida_server(self):
        if not self.is_running_frida_server():
            self.install_frida_server()


class adb(Shell):
    
    def __init__(self):
        clz_name = self.__class__.__name__
        logger_path = os.path.join(config.ifrida_session_dir_path,clz_name)
        self.logger = config.get_logger(logger_path,with_timestamp=False,promot=clz_name)
        self.is_adb_exist = None
        self.start_adb()
        self.devices()

    def devices(self):
        if self.start_adb():
            devices = self.exec("adb devives").split('\n')[1:]
            return devices


    def connect(self,serial):
        self.exec(f"adb connect {serial}")
        return RemoteDevice(serial , self)

    def check_adb_exist(self):
        if self.is_adb_exist != None:
            return self.is_adb_exist 
        self.is_adb_exist = "Android Debug Bridge" in self.exec("adb").out
        return self.is_adb_exist
    def start_adb(self):
        if self.check_adb_exist():
            self.exec(f'adb start-server', supress_error=True)
        else:
            self.logger.error("no adb or adb stat-server error")
            return False
    def is_win(self):
        self.arch = platform.architecture()
        if self.arch[1] == "ELF":
            self.is_win = False
        else:
            self.is_win = True 

    def push(self,serial, src, dst):
        return self.exec(f'adb -s {serial} push {src} {dst}')

    def reverse(self,serial, port):
        return self.exec(f'adb -s {serial} reverse tcp:{port} tcp:{port}')

    def clear_reverse(self,serial, remote_port):
        return self.exec(f'adb -s {serial} reverse --remove tcp:{remote_port}')

    def forward(self,serial, adb_port, remote_port):
        return self.exec(f'adb -s {serial} forward tcp:{adb_port} tcp:{remote_port}')

    def clear_forward(self,serial, adb_port):
        return self.exec(f'adb -s {serial} forward --remove tcp:{adb_port}')
    def unsafe_shell(self, serial,command, root=False, quiet=False):
        return self.exec(f"adb -s {serial} shell \"{command}\"")


    