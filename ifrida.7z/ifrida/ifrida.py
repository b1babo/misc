
#!/usr/bin/env python
'''
'''
#from ptpython.repl import embed,PythonRepl
#from ptpython.python_input import PythonInput

from device import * 
import config

class Help:

    def __init__(self):
        self.help_str = ""
    def help(self):
        def get_methods(obj):
            methods = []
            for attr in dir(obj):
                func = getattr(obj,attr)
                if not attr.startswith("__") and callable(func) and attr !="help":
                    methods.append(func)

            return methods
        print("welcome ifrida!")
        print("type session.help() to get more infomation!" )
        if self.help_str =="":
            methods = get_methods(self)
            for function in methods :
                self.help_str = self.help_str + function.__doc__ + "\n"
        print(self.help_str)





class IFridaSession(Help):
    
    def __init__(self):
        super().__init__()


        clz_name = self.__class__.__name__
        logger_path = os.path.join(config.ifrida_session_dir_path,clz_name)
        self.logger = config.get_logger(logger_path,clz_name)
        
        self.adb = adb()
        self.devices = {}
        self.devices["local"] = LocalDevice()
        self.cur_device = None
        self.cur_process = None
        self.cur_processes =None
    def connect_device(name):
        '''session.connect(name): connect remote device.'''
        self.adb.connect(name)

    def list_devices(self):
        '''session.devices(name,script): list devices.'''
        return self.adb.devices()
    def get_device(self,device):
        '''session.get_device(device): get devices.'''
        if device in self.devices:
            d =  self.devices[device]
        else:
            d = RemoteDevice(name,adb=self.adb)
            self.devices[name] = d
        return d
    def current_hook_process(self):
        '''session.current_hook_process(name): get the current front hooking process.'''
        print(self.cur_process)
    def current_hooking_processes(self):
        '''session.current_process(name): get all the current  hooking process.'''
        print(self.cur_processes)
    def switch_hooking_process(self,name):
        '''session.switch_process(name): switch to a hooking process to front.'''
        self.cur_device = None
    def hook_process(self,device,name,script):
        '''session.hook_process(name,script): hook process within a device using script.'''
        d = self.get_device(device)
        d.attach_process(name,script)
    def load_script(self,process,script):
        '''session.load_script(process,script): load script into  process hooked.'''
        
        for d in devices:
            d.attach_process(name,script)
    def enumerate_processes(self,device):
        '''session.enumerate_processes(device): enumerate processes of a device.'''
        d = self.get_device(device)
        d.enumerate_processes()



    def __repr__(self):
        return "this is session"








    



global_dict = {}




def main():
    session = IFridaSession()
    session.help()
    global_dict = {"session":session}
    #embed(global_dict, locals(), vi_mode=False)

if __name__ == "__main__":
    main()
else:
    session = IFridaSession()
    session.help()